#Logan Wyas
#make sure that the folder is downloaded, and make sure the current working directory is on this folder.
import PIL
import os.path
import PIL.ImageDraw

#color - options: red, green, blue, yellow, orange, purple, black, white, pink
#wide - type in how many pixels wide you want the frame to be
#symbol - options: football, music_note, chef_hat, computer, car (if no symbol, type "none" in place of a symbol)
#shape - options: circle, triangle, bookmark (if no shape, type "none" in place of a shape)
#shape_color - options: red, green, blue, yellow, orange, purple, black, white, pink (if no shape, type "none" in place of the color)
#when typing in the options (except for wide), make sure to use quotation marks
def family_photo(color, wide, symbol, shape, shape_color):
    
    directory = os.getcwd()
    image_directory = os.path.join(directory, 'Images to Alter')
    new_directory = os.path.join(directory, 'Altered Images')
    try:
        os.mkdir(new_directory)
    except OSError:
        pass
    
    image_list = []
    file_list = []
    
    directory_list = os.listdir(image_directory)
    for entry in directory_list:
        absolute_filename = os.path.join(image_directory, entry)
        try:
            image = PIL.Image.open(absolute_filename)
            file_list += [entry]
            image_list += [image]
        except IOError:
            pass
            
    if color == "red":
        color = (204,0,0)
    elif color == "blue":
        color = (0,0,153)
    elif color == "green":
        color = (76,153,0)
    elif color == "yellow":
        color = (255,255,102)
    elif color == "orange":
        color = (255,153,51)
    elif color == "white":
        color = (255,255,255)
    elif color == "black":
        color = (0,0,0)
    elif color == "purple":
        color = (127,0,255)
    elif color == "pink":
        color = (255,153,204)
    else:
        print("Invalid color. Defaulting to color yellow")
        color = (255,255,102)
        
    if shape_color == "red":
        shape_color = (255,0,0)
    elif shape_color == "blue":
        shape_color = (0,0,255)
    elif shape_color == "green":
        shape_color = (0,255,0)
    elif shape_color == "yellow":
        shape_color = (0,0,255)
    elif shape_color == "orange":
        shape_color = (0,0,255)
    elif shape_color == "white":
        shape_color = (255,255,255)
    elif shape_color == "black":
        shape_color = (0,0,0)
    elif shape_color == "purple":
        shape_color = (0,0,255)
    elif shape_color == "pink":
        shape_color = (0,0,255)
    elif shape_color == "none":
        pass
    else:
        print("Invalid color for shape. Defaulting to color yellow")
        shape_color = (255,255,102)
        
    if symbol == "football":
        symbol = PIL.Image.open(r"Symbol Source\football.png").convert("RGBA")
    elif symbol == "car":
        symbol = PIL.Image.open("Symbol Source\car.png").convert("RGBA")
    elif symbol == "computer":
        symbol = PIL.Image.open("Symbol Source\computer.png").convert("RGBA")
    elif symbol == "chef_hat":
        symbol = PIL.Image.open("Symbol Source\chef.png").convert("RGBA")
    elif symbol == "music_note":
        symbol = PIL.Image.open("Symbol Source\music_note.png").convert("RGBA")
    elif symbol == "none":
        pass
    else:
        print("Invalid symbol. Defaulting to no symbol")
        symbol = "none"
                       
    for n in range(len(image_list)):
        w, h = image_list[n].size
        fh = h+(wide*2)
        fw = w+(wide*2)
        filename, filetype = file_list[n].split('.')
        frame_mask = PIL.Image.new('RGBA', (w+(wide*2),h+(wide*2)), color)
        drawing_frame_layer = PIL.ImageDraw.Draw(frame_mask)
        drawing_frame_layer.polygon([(0,0),(0,fh),(fw,0),(fw,fh)],fill=color)
        frame_mask.paste(image_list[n], (wide,wide))
        if symbol != "none":
            symbol = symbol.resize((int(w*.2), int(h*.2)), PIL.Image.ANTIALIAS)
            frame_mask.paste(symbol, (int(w*.9),int(h*.9)), mask=symbol)
        if shape == "circle":
            drawing_frame_layer.ellipse([(w,0), (fw, wide*2)], fill=shape_color)
        elif shape == "triangle":
            drawing_frame_layer.polygon([(int(w*.9),0),(fw,int(h*.2)),(fw,0)],fill=shape_color)
        elif shape == "bookmark":
            drawing_frame_layer.polygon([(int(w*.94),0),(int(w*.94),int(h*.2)),(int(w*.97),int(h*.17)),(w,int(h*.2)),(w,0)],fill=shape_color)
        elif shape == "none":
            pass
        else:
            print("Invalid shape. Defaulting to no shape")
            shape = "none"
            
        new_image_filename = os.path.join(new_directory, filename + '.png')
        frame_mask.save(new_image_filename)