#Logan Wyas
#make sure that the whole folder is downloaded, and make sure the current working directory is on this folder.
import PIL
import os.path  
import PIL.ImageDraw   
import PIL.ImageEnhance     

def round_corners(original_image, percent_of_side):

    width, height = original_image.size
    radius = int(percent_of_side * min(width, height)) # radius in pixels

    rounded_mask = PIL.Image.new('RGBA', (width, height), (127,0,127,0))
    drawing_layer = PIL.ImageDraw.Draw(rounded_mask)
    
    drawing_layer.polygon([(radius,0),(width-radius,0),
                            (width-radius,height),(radius,height)],
                            fill=(127,0,127,255))
    drawing_layer.polygon([(0,radius),(width,radius),
                            (width,height-radius),(0,height-radius)],
                            fill=(127,0,127,255))

    drawing_layer.ellipse((0,0, 2*radius, 2*radius), 
                            fill=(0,127,127,255))
    drawing_layer.ellipse((width-2*radius, 0, width,2*radius), 
                            fill=(0,127,127,255))
    drawing_layer.ellipse((0,height-2*radius,  2*radius,height), 
                            fill=(0,127,127,255))
    drawing_layer.ellipse((width-2*radius, height-2*radius, width, height), 
                            fill=(0,127,127,255))
                         
    result = PIL.Image.new('RGBA', original_image.size, (0,0,0,0))
    result.paste(original_image, (0,0), mask=rounded_mask)
    return result
    
def get_images(directory=None):
    
    if directory == None:
        directory = os.getcwd()
        
    image_list = []
    file_list = []
    
    directory_list = os.listdir(directory)
    for entry in directory_list:
        absolute_filename = os.path.join(directory, entry)
        try:
            image = PIL.Image.open(absolute_filename)
            file_list += [entry]
            image_list += [image]
        except IOError:
            pass
    return image_list, file_list

def round_corners_of_all_images(directory=None):
    
    if directory == None:
        directory = os.getcwd()
        
    new_directory = os.path.join(directory, 'modified')
    try:
        os.mkdir(new_directory)
    except OSError:
        pass  
    
    image_list, file_list = get_images(directory)  

    for n in range(len(image_list)):
        
        filename, filetype = file_list[n].split('.')
        
        new_image = round_corners(image_list[n],.30)
        new_image_filename = os.path.join(new_directory, filename + '.png')
        new_image.save(new_image_filename)    

def frame_all_images(color, wide, directory=None):
    
    if directory == None:
        directory = os.getcwd()
    new_directory = os.path.join(directory, 'modified')
    try:
        os.mkdir(new_directory)
    except OSError:
        pass
    
    image_list, file_list = get_images(directory)

    for n in range(len(image_list)):
        w, h = image_list[n].size
        filename, filetype = file_list[n].split('.')
        frame_mask = PIL.Image.new('RGBA', (w+(wide*2),h+(wide*2)), color)
        drawing_frame_layer = PIL.ImageDraw.Draw(frame_mask)
        drawing_frame_layer.polygon([(0,0),(0,h+(wide*2)),(w+(wide*2),0),(w+(wide*2),h+(wide*2))],fill=color)
        frame_mask.paste(image_list[n], (wide,wide))
        new_image_filename = os.path.join(new_directory, filename + '.png')
        frame_mask.save(new_image_filename)    
    
#put a watermark on an image
#watermark_name - type the full name of the image that you want to use as a watermark (ex. "watermark.png", and make sure to use quotes) (make sure that the image is in the "Watermark" folder) (works best with a .png and text)
#opacity - type the amount that you want to have transparent (from 0-1, 0 being fully transparent, 1 being not transparent at all)
def alter_all_images(watermark_name, opacity, directory=None):
    
    if directory == None:
        directory = os.getcwd()
    new_directory = os.path.join(directory, 'Altered Images')
    try:
        os.mkdir(new_directory)
    except OSError:
        pass
    
    image_list, file_list = get_images(directory + "\Images to Alter")
    watermark = PIL.Image.open(directory + "\Watermark\\" + watermark_name).convert("RGBA")
    alpha = watermark.split()[3]
    alpha = PIL.ImageEnhance.Brightness(alpha).enhance(opacity)
    watermark.putalpha(alpha)

    for n in range(len(image_list)):
        w, h = image_list[n].size
        filename, filetype = file_list[n].split('.')
        watermark = watermark.resize((w,h), PIL.Image.ANTIALIAS)
        image_list[n].paste(watermark, (0,0), mask=watermark)
        new_image_filename = os.path.join(new_directory, filename + ".png")
        image_list[n].save(new_image_filename)   